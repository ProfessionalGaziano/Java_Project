package poligono;
import java.io.*;

public class Test {
    public static void main(String[] args) {
        int scelta=0, x=0,y=0;
        InputStreamReader input=new InputStreamReader(System.in);
        BufferedReader tastiera=new BufferedReader(input);
        Poligono poli=new Poligono();
        
        do{
            System.out.println("1) Inserisci, 2) Elimina, 3) Stampa, "
                    + "0) Fine");
            try{
                scelta=Integer.parseInt(tastiera.readLine());
            }catch(Exception e){}
            
            switch(scelta){
                case 1:
                    System.out.println("Quanti lati?");
                    try{
                        int lati=Integer.parseInt(tastiera.readLine());
                        for(int i=0;i<lati;i++){
                            System.out.println("Inserire x");
                            try{
                                x=Integer.parseInt(tastiera.readLine());
                            }catch(Exception e){}
                            System.out.println("Inserire y");
                            try{
                                y=Integer.parseInt(tastiera.readLine());
                            }catch(Exception e){}
                            Punto p=new Punto(x,y);
                            poli.aggiungi(p);
                        }
                    }catch(Exception e){}
                    break;
                
                case 2:
                    poli.stampa();
                    try{
                        System.out.println("Inserire x");
                        try{
                            x=Integer.parseInt(tastiera.readLine());
                        }catch(Exception e){}
                        System.out.println("Inserire y");
                        try{
                            y=Integer.parseInt(tastiera.readLine());
                        }catch(Exception e){}
                        
                        poli.togli(x,y);
                    }catch(Exception e){}
                    break;
                
                case 3:
                    poli.stampa();
                    break;
                    
            }
        }while(scelta!=0);
        
    }
    
}
