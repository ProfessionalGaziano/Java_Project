package poligono;
import java.util.*;

public class Poligono {

    private Vector poligono; //attributo
    
    public Poligono(){
        poligono=new Vector(1,1);
    }
    
    public void aggiungi(Punto p){
        poligono.addElement(p);
    }
    
    public void stampa(){
        Punto p;
        System.out.println("Elenco punti");
        
        for(int i=0;i<poligono.size();i++){
            p=(Punto)poligono.elementAt(i);
            System.out.println(p);
        }
        
    }
    
    public boolean togli(int x, int y){
        Punto p;
        boolean b=false;
        for(int i=0;i<poligono.size();i++){
            p=(Punto)poligono.elementAt(i);
            if((p.getX()==x) &&  (p.getY()==y)){
                poligono.removeElementAt(i);
                b=true;
            }
        }
        return b;
    }
    
    public int size(){
        return poligono.size();
    }
    
    public String elemento(int i){
        Punto p;
        p=(Punto)poligono.elementAt(i);
        return p.toString();
    }
    
}