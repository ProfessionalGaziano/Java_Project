
package poligono;

public class Punto {
    private int x,y; //attributi
    
    public Punto(int x, int y){ //metodo costruttore
        this.x=x;
        this.y=y;
    }
    
    public String toString(){
        return "x= "+x+" y= "+y;
    }
    
    public int getX(){
        return x;
    }
    
    public int getY(){
        return y;
    }
}
