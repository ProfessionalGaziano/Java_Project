/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prezzocarburante;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author nb
 */
public class PrezzoCarburante {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String scelta="";
        InputStreamReader input=new InputStreamReader(System.in);
        BufferedReader tastiera=new BufferedReader(input);
        Pila p=new Pila();
        double quantita=0, prezzo=0;
        
        do{
            System.out.println("Inserisci il prezzo del carburante: ");
            try{
                prezzo=Double.parseDouble(tastiera.readLine());
            }catch(Exception e){}
            p.push(prezzo);
            System.out.println("Un altro prezzo? (si, no)");
            try{
                scelta=tastiera.readLine();
            }catch(Exception e){}
        }while(scelta.equals("si"));
        System.out.println("Inserire la quantità di carburante: ");
        try{
        quantita=Double.parseDouble(tastiera.readLine());
        }catch(Exception e){}
        double costo=((Double)p.top())*quantita;
        System.out.println("L'ultimo prezzo è: €"+(Double)p.top());
        System.out.println("Il costo mensile è: €"+costo);
    }
    
}
