/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ruolo.pkg2;

/**
 *
 * @author Utente
 */
public interface Mostro extends Personaggio {
    
    public void Mordi();
    
}
