/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ruolo.pkg2;

/**
 *
 * @author Utente
 */
public class Eroe implements Umano {
    
    protected int forza=10;
    
    public Eroe(){
    
    forza=15;
    
    
    }
    
    public void combatti(){
  
    forza=forza-3;
  
    
    }
    
    public String getForza(){
    
    
      
      return "La forza dell'eroe e':   "+forza;
    }
  
}
