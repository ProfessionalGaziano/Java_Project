/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ruolo.pkg2;

/**
 *
 * @author Utente
 */
public class Licantropo implements Umano,Mostro{
    Scelta s=new Scelta();
    
   protected int Forzau=14;
   protected int Forzat=16;
   protected boolean trasformazione=false;
   
    
   public void combatti(){
  
       if(trasformazione==false){
   
  
   
   Forzau=Forzau-2;
   if(Forzau==0){
   System.out.println("il ");
   }
  
   
   }
  
   
   }
    public void Mordi(){
     trasformazione=true;
        if(trasformazione==true){
    
    Forzat=Forzat-3;
    
    }
   
   
   }
    public String getForza(){
   
   if(trasformazione==true){
   
       return "La forza dell' licantropo: "+Forzat;
       
   }else{
      trasformazione=false;
    return "La forza dell' umano e':  "+Forzau;
   }
  
}
}
