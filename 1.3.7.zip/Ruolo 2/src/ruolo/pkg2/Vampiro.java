/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ruolo.pkg2;

/**
 *
 * @author Utente
 */
public class Vampiro implements Mostro {
    
    protected int forza;
    
    
    public Vampiro(){

    forza=18;

}

public void Mordi(){

forza=forza-2;
if(forza==0){

System.out.println("Il vampiro e'morto");
}

}

public String getForza(){


return "Forza rimanente come vampiro:  "+forza; 

}
    
}

